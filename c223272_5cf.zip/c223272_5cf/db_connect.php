<?php 
$connnection=mysqli_connect("localhost","root","","c223272_5cf");
?>
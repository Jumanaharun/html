<?php 
$connnection=mysqli_connect("localhost","root","","5cf_c223271");
?>